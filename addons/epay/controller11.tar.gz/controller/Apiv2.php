<?php

namespace addons\epay\controller;

use addons\epay\library\Service;
use app\admin\model\PayOrder;
use app\common\model\Log;
use think\addons\Controller;
use Exception;
use KTools\KTools;
use think\Config;
use app\admin\model\pay\Type;
use think\exception\DbException;
use think\db\exception\DataNotFoundException;
use think\db\exception\ModelNotFoundException;


/**
 * Class Apiv2 for cpay
 * @package addons\epay\controller
 */
class Apiv2 extends Controller
{

    protected $layout = 'default';

    /**
     *
     */
    //$token对应shop表
    protected $token = '';
    //商户id
    protected $shopid = 0;
    //回调通知地址
    protected $sys_notifyurl = '';

    //平台网关
    protected $apiUrl = "";

    protected $config = [];

    public function _initialize()
    {
        parent::_initialize();
    }

    public function submit()
    {

        $out_trade_no = $this->request->request("out_trade_no");
        $amount = $this->request->request('amount');

        //验证支付方式是否可用
        $PayTypeM  = new Type();
        $payTypeInfo = false;
        $paytype = 'alipay_wap';
        try {
            $payTypeInfo = $PayTypeM->where('type', $paytype)->where('status',1)->find();
        } catch (DataNotFoundException $e) {
        } catch (ModelNotFoundException $e) {
        } catch (DbException $e) {
        }
        if (!$payTypeInfo)
        {
            $this->error('支付通道不可用');
        }
        $payTypeInfo['config'] = json_decode($payTypeInfo['config'],true);
        $this->shopid = $payTypeInfo['config']['shopid'];
        $this->token = $payTypeInfo['config']['token'];
        $this->sys_notifyurl = $payTypeInfo['config']['sys_notifyurl'];
        $this->apiUrl = $payTypeInfo['config']['apiUrl'];


        //channel
        //0: 支付宝转账银行卡
        //2：支付宝固码
        //3：银行卡转账到银行卡
        //4: 支付宝转账码
        //6：云闪付固定金额收款码
        //7：支付宝转红包
        //8：其余方式channelid需咨询商务经理获取
        //14: 支付宝+淘宝
        //若 channel 参数为空，则默认当前成功率最高的方案，且不加入 sign 签名

        $url = $this->CpayindexH5($out_trade_no,$amount,14);
        if ($url['status'] == 1 && isset($url['data']['url'])) {
            //重定向到请求回来的url
            $this->redirect($url['data']['url']);
        } else {
            $OrderM = new PayOrder();
            $orderInfo = $OrderM->where('out_trade_no',$out_trade_no)->select();
            if ($orderInfo && count($orderInfo) ===1)
            {
                $OrderM->where('out_trade_no',$out_trade_no)->delete();
            }
            $this->error("系统繁忙");
        }

    }


    /**
     * 支付成功回调
     */
    public function notifyx()
    {

        //验证支付方式是否可用
        $PayTypeM  = new Type();
        $payTypeInfo = false;
        try {
            $payTypeInfo = $PayTypeM->where('platform', 'cpay')->find();
        } catch (DataNotFoundException $e) {
        } catch (ModelNotFoundException $e) {
        } catch (DbException $e) {
        }
        if (!$payTypeInfo)
        {
            $this->error('支付通道不可用');
        }
        $payTypeInfo['config'] = json_decode($payTypeInfo['config'],true);
        $this->shopid = $payTypeInfo['config']['shopid'];
        $this->token = $payTypeInfo['config']['token'];


        /*{
            "s": "/addons/epay/apiv2/notifyx",
            "channel": "14",
            "money": "1",
            "pay_money": "1",
            "shop_id": "2",
            "mark_buy": "2088712992513751",
            "orderid": "20190428200040011100750049852078",
            "end_time": "2019-04-28 11:12:35",
            "create_time": "2019-04-28 11:11:59",
            "mark_sell": "15564211199894693",
            "status": "1",
            "trade_no": "E201904280311598743",
            "sign": "5564ab48feeb43de50634270a84e3234"
        }*/



        $payData = array();
        $payData['channel'] = $this->request->request('channel','');
        $payData['money'] = $this->request->request('money','');
        $payData['pay_money'] = $this->request->request('pay_money','');
        $payData['shop_id'] = $this->request->request('shop_id','');
        $payData['mark_buy'] = $this->request->request('mark_buy','');
        $payData['orderid'] = $this->request->request('orderid','');
        $payData['end_time'] = $this->request->request('end_time','');
        $payData['create_time'] = $this->request->request('create_time','');
        $payData['mark_sell'] = $this->request->request('mark_sell','');
        $payData['status'] = $this->request->request('status','');
        $payData['trade_no'] = $this->request->request('trade_no','');
        $payData['sign'] = $this->sign($payData,$this->token);
        $sign = $this->request->request('sign','');
        if ($sign===$payData['sign'])
        {
            if ($payData['status'] ==1)
            {
                try {

                    $OrderM = new PayOrder();

                    //修改订单状态
                    $out_trade_no = $payData['trade_no'];
                    $myOrder = array();
                    $myOrder['sys_order_id'] = $payData['orderid'];
                    $myOrder['status'] = 2;//已经支付
                    $myOrder['paydate'] = $payData['end_time'];
                    $myOrder['paytime'] = strtotime($myOrder['paydate']);
                    $where = array();
                    $where['out_order_id'] = $out_trade_no;
                    $where['status'] = array('in','0,1');
                    $OrderM->where($where)->update($myOrder);

                    //订单详情
                    $where = array();
                    $where['out_order_id'] = $out_trade_no;
                    $orderInfo = $OrderM->where($where)->find();


                    //下发商户通知
                    $result = \app\admin\library\Service::notify($orderInfo['id']);

                    $APiC = new Api();
                    //扣除费率及记账
                    $APiC->dealServiceCharge($orderInfo);



                    //你可以在此编写订单逻辑
                } catch (Exception $e) {

                }

            }
            echo '{"code":1,"msg":"ok"}';
            return;
        }else{
            $this->error('error');
        }

    }

    /*public function pay()
    {
        if (request()->isGet()){
            $money = input('money');
            if($money<0.01){
                return "输入金额必须大于0.01";
            }
            //生成商家订单号trdeNo
            $trade_no = $this->order_number();
            //请求Cpayindex   默认银行卡模式
            $url = $this->CpayindexH5($trade_no,$money,3);
            if ($url['status'] == 1 && isset($url['data']['url'])) {
                //重定向到请求回来的url
                $this->redirect($url['data']['url']);
            } else {
                return json($url);
            }
        }else{
            return "非法请求";
        }
    }*/

    //Cpayindex拼接支付URL
    public function CpayindexH5($trade_no, $money, $channel=null)
    {
        $params = array(
            'trade_no' => $trade_no,
            //转账方式
            'channel' => $channel,
            'money' => $money,
            'shop_id' => $this->shopid,
            'tzurl' => urlencode($this->sys_notifyurl)
        );
        if (isset($channel)) {
            $params['channel'] = $channel;
        }
        $sign = $this->sign($params,$this->token);
//        var_dump($sign);
        $domain = $this->apiUrl;
        //二维码url
        //http://cpay.adbng.top/indexH5
        if (isset($channel)) {
            $url = $domain."/indexH5?trade_no=".$params['trade_no']."&money=".$params['money']."&shop_id=".$params['shop_id']."&channel=".$channel."&tzurl=".$params['tzurl']."&sign=".$sign;
        } else {
            $url = $domain."/indexH5?trade_no=".$params['trade_no']."&money=".$params['money']."&shop_id=".$params['shop_id']."&tzurl=".$params['tzurl']."&sign=".$sign;
        }
        $curlres = file_get_contents($url);
        if ($curlres) {
            $koala = json_decode($curlres,true);
            return $koala;
        } else {
            return $list = [
                'status'  => 0,
                'message' => $curlres
            ];
        }
    }

    //签名
    public function sign($params,$token)
    {
        // 1.按字典序排序数组参数
        ksort($params);
        // 2.键值对排序
        //var_dump($params);
        $string = KTools::build_query_cpay($params);
        //var_dump($string);
        // 3.拼接上商户token
        $string = $string . "&token=" . $token;
        // 4.字符串转为小写
        $result = strtolower($string);
        // 5.md5加密最后的字符串
        //var_dump($result);
        $result = md5($result);
        return $result;
    }

    //支付页面
    public function indexH5()
    {
        return $this->fetch();
    }

    //生成唯一订单号
    public function order_number()
    {
        $order_date = date('Y-m-d');
        $order_id_main = date('YmdHis') . rand(100,999);
        $order_id_len = strlen($order_id_main);
        $order_id_sum = 0;
        for($i=0; $i<$order_id_len; $i++){
            $order_id_sum += (int)(substr($order_id_main,$i,1));
        }
        //唯一订单号码（YYYYMMDDHHIISSNNNNNNNNCC）
        $order_id = $order_id_main.str_pad((100 - $order_id_sum % 100) % 100,2,'0',STR_PAD_LEFT);
        return $order_id;
    }



}
